import 'package:flutter/material.dart';

class Content extends StatelessWidget {
  const Content({super.key});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: -20,
      left: 30,
      right: 30,
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: buildContentColumn(Icons.headphones,
                  'Customer Support 24/7', 'Inatant access to Support'),
            ),
            Flexible(
              child: buildContentColumn(Icons.payment, '100% Secure Payment',
                  'We Ensure your money Is safe'),
            ),
            Flexible(
              child: buildContentColumn(Icons.person, 'Earnings On Referal',
                  'Earn more when you refer a friend'),
            ),
            Flexible(
              child: buildContentColumn(Icons.bus_alert, 'Efficient Deliver',
                  'We deliver as promised'),
            )
          ],
        ),
      ),
    );
  }
}

Widget buildContentColumn(IconData icon, String title, String subtitle) {
  return Row(
    children: [
      Icon(
        icon,
        size: 45,
        color: Colors.green,
      ),
      const SizedBox(width: 10),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 16,
            ),
          ),
        ],
      ),
    ],
  );
}
