import 'package:flutter/material.dart';
// import 'package:mobilepage/pages/content.dart';
import 'package:mobilepage/pages/shoppingpage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Image.asset(
            'assets/second.jpg',
            fit: BoxFit.cover,
          ),
          Container(
            color:
                Colors.black.withOpacity(0.5), // Adjust the opacity as needed
          ),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 50.0, vertical: 25.0),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Align(
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    // width: MediaQuery.of(context).size.width *
                    //     0.6, // Set to half the screen width
                    child: RichText(
                      text: TextSpan(
                        children: [
                          const TextSpan(
                            text: 'Save over 50% Weekly when you ',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          WidgetSpan(
                            child: Container(
                              margin: const EdgeInsets.all(3),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 3.0, vertical: 4.0),
                              decoration: BoxDecoration(
                                color: Colors.orange,
                                borderRadius: BorderRadius.circular(9),
                                // Add border
                              ),
                              child: const Text(
                                'Group Buy',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const TextSpan(
                            text: 'With us.',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      softWrap: true,
                      textAlign: TextAlign.left,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width * 0.6,
                    child: const Text(
                      'Group-buy grocries and other items with other frugal shoppers,split the cost and save on your shopping bills.',
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ShoppingPage()),
                      );
                    },
                    icon: const Icon(Icons.arrow_forward),
                    label: const Text(
                      'Shop Now',
                      style: TextStyle(color: Colors.green),
                    ),
                    style: ElevatedButton.styleFrom(
                      iconColor: Colors.green,
                      backgroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 24),
                      textStyle:
                          const TextStyle(fontSize: 18, color: Colors.green),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          // Positioned(
          //   bottom: -20,
          //   left: 30,
          //   right: 30,
          //   child: Container(
          //     padding: const EdgeInsets.all(16.0),
          //     decoration: BoxDecoration(
          //       color: Colors.white,
          //       borderRadius: BorderRadius.circular(10.0),
          //     ),
          //     child: Row(
          //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //       children: [
          //         Flexible(
          //           child: buildContentColumn(Icons.headphones,
          //               'Customer Support 24/7', 'Inatant access to Support'),
          //         ),
          //         Flexible(
          //           child: buildContentColumn(Icons.payment,
          //               '100% Secure Payment', 'We Ensure your money Is safe'),
          //         ),
          //         Flexible(
          //           child: buildContentColumn(
          //               Icons.person,
          //               'Earnings On Referal',
          //               'Earn more when you refer a friend'),
          //         ),
          //         Flexible(
          //           child: buildContentColumn(Icons.bus_alert,
          //               'Efficient Deliver', 'We deliver as promised'),
          //         )
          //       ],
          //     ),
          //   ),
          // )
        ],
      ),
    );
  }
}

Widget buildContentColumn(IconData icon, String title, String subtitle) {
  return Row(
    children: [
      Icon(
        icon,
        size: 45,
        color: Colors.green,
      ),
      const SizedBox(width: 10),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 16,
            ),
          ),
        ],
      ),
    ],
  );
}
