package com.example.mobilepage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
